/* Automatically generated */
